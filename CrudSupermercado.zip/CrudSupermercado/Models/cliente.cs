using System.ComponentModel.DataAnnotations;
using System.Numerics;
namespace CrudSupermercado.Models;

public class Cliente : Entity
{
    [Required(ErrorMessage = "O CPF/CNPJ é obrigatório.")]
    [Display(Name = "CPF/CNPJ")]
    [RegularExpression(@"^\d+$", ErrorMessage = "O CPF/CNPJ deve conter apenas números.")]
    public string Cpf { get; set; }

    [Required(ErrorMessage = "A Inscrição Estadual é obrigatória.")]
    [Display(Name = "Inscrição Estadual")]
    [RegularExpression(@"^\d+$", ErrorMessage = "A Inscrição Estadual deve conter apenas números.")]
    public string InscricaoEstadual { get; set; }

    [Required(ErrorMessage = "O Nome é obrigatório.")]
    public string Nome { get; set; }

    [Required(ErrorMessage = "O Nome Fantasia é obrigatório.")]
    [Display(Name = "Nome Fantasia")]
    public string NomeFantasia { get; set; }

    [Required(ErrorMessage = "O Endereço é obrigatório.")]
    public string Endereco { get; set; }

    [Required(ErrorMessage = "O Número é obrigatório.")]
    public string Numero { get; set; }

    [Required(ErrorMessage = "O Bairro é obrigatório.")]
    public string Bairro { get; set; }

    [Required(ErrorMessage = "A Cidade é obrigatória.")]
    public string Cidade { get; set; }

    [Required(ErrorMessage = "O Estado é obrigatório.")]
    public string Estado { get; set; }

    [Required(ErrorMessage = "A Data de Nascimento é obrigatória.")]
    [Display(Name = "Data de Nascimento")]
    [DataType(DataType.Date)]
    public DateTime DataNascimento { get; set; }

    public string Imagem { get; set; }
}
