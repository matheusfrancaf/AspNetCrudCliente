using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using CrudSupermercado.Models;
public class RepositorioEstadosCidades
{
    private readonly string arquivoRepositorio;

    public RepositorioEstadosCidades(string caminhoArquivo)
    {
        arquivoRepositorio = caminhoArquivo;
    }

    public EstadosCidades Listar()
    {
        if (!File.Exists(arquivoRepositorio))
        {
            return new EstadosCidades { Estados = new List<Estado>() };
        }

        try
        {
            string json = File.ReadAllText(arquivoRepositorio);
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true // Permite correspondência insensível a maiúsculas/minúsculas
            };

            return JsonSerializer.Deserialize<EstadosCidades>(json, options);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Erro ao ler o arquivo {arquivoRepositorio}: {ex.Message}");
            return new EstadosCidades { Estados = new List<Estado>() };
        }
    }
}