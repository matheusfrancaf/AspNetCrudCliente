using System.ComponentModel.DataAnnotations;
using System.Reflection;
using System.Collections;
using Microsoft.VisualBasic;

namespace CrudSupermercado.Models.ViewModel;
public class ClienteViewModel
{
    public ClienteViewModel()
    {

    }
    public ClienteViewModel(Cliente model)
    {
        this.Id = model.Id;
        this.Cpf = model.Cpf;
        this.InscricaoEstadual = model.InscricaoEstadual;
        this.Nome = model.Nome;
        this.NomeFantasia = model.NomeFantasia;
        this.Endereco = model.Endereco;
        this.Numero = model.Numero;
        this.Bairro = model.Bairro;
        this.Cidade = model.Cidade;
        this.Estado = model.Estado;
        this.DataNascimento = model.DataNascimento;
        this.Imagem = model.Imagem;
    }
    public Cliente Parse()
    {
        return new Cliente
        {
            Id = this.Id,
            Cpf = this.Cpf,
            InscricaoEstadual = this.InscricaoEstadual,
            Nome = this.Nome,
            NomeFantasia = this.NomeFantasia,
            Endereco = this.Endereco,
            Numero = this.Numero,
            Bairro = this.Bairro,
            Cidade = this.Cidade,
            Estado = this.Estado,
            DataNascimento = this.DataNascimento,
            Imagem = this.Imagem
        };

    }
    public int Id { get; set; }

    [Required(ErrorMessage = "CPF/CNPJ é obrigatório.")]
    [Display(Name = "CPF/CNPJ")]
    [RegularExpression(@"^\d+$", ErrorMessage = "O CPF/CNPJ deve conter apenas números.")]
    [CpfCnpjLength]
    public string Cpf { get; set; }

    [Required(ErrorMessage = "Inscrição Estadual é obrigatória.")]
    [Display(Name = "Inscrição Estadual")]
    [RegularExpression(@"^\d+$", ErrorMessage = "A Inscrição Estadual deve conter apenas números.")]
    [StringLength(15, ErrorMessage = "A Inscrição Estadual não pode ter mais de 15 caracteres.")]
    public string InscricaoEstadual { get; set; }

    [Required(ErrorMessage = "Nome é obrigatório.")]
    [Display(Name = "Nome")]
    public string Nome { get; set; }

    [Required(ErrorMessage = "Nome Fantasia é obrigatório.")]
    [Display(Name = "Nome Fantasia")]
    public string NomeFantasia { get; set; }

    [Required(ErrorMessage = "Endereço é obrigatório.")]
    [Display(Name = "Endereço")]
    public string Endereco { get; set; }

    [Required(ErrorMessage = "Número é obrigatório.")]
    [Display(Name = "Número")]
    public string Numero { get; set; }

    [Required(ErrorMessage = "Bairro é obrigatório.")]
    [Display(Name = "Bairro")]
    public string Bairro { get; set; }

    // [Required(ErrorMessage = "Cidade é obrigatório.")]
    [Display(Name = "Cidade")]
    public string Cidade { get; set; }

    // [Required(ErrorMessage = "Estado é obrigatório.")]
    [Display(Name = "Estado")]
    public string Estado { get; set; }

    [Required(ErrorMessage = "Data de nascimento é obrigatório.")]
    [Display(Name = "Data de Nascimento")]
    [DataType(DataType.Date)]
    public DateTime DataNascimento { get; set; }
    public string Imagem { get; set; }

    public class CpfCnpjLengthAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var strValue = value as string;
            if (strValue == null || (strValue.Length != 11 && strValue.Length != 14))
            {
                return new ValidationResult("O CPF/CNPJ deve ter exatamente 11 ou 14 caracteres.");
            }
            return ValidationResult.Success;
        }
    }
}

