namespace CrudSupermercado.Models.ViewModel;
public class UsuarioViewModel: Entity
{
    public UsuarioViewModel()
    {

    }

    public UsuarioViewModel(Usuario model)
    {
        this.Id = model.Id;
        this.Login = model.Login;
        this.Senha = model.Senha;
    }
    public Usuario Parse()
    {
        return new Usuario
        {
            Id = this.Id,
            Login = this.Login,
            Senha = this.Senha
        };
    }
    public string Login { get; set; }
    public string Senha { get; set; }
}