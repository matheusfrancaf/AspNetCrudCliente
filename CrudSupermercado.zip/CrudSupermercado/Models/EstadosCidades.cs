using System.ComponentModel.DataAnnotations;
using System.Numerics;
namespace CrudSupermercado.Models;
public class EstadosCidades
{
    public List<Estado> Estados { get; set; }
}

public class Estado
{
    public string Sigla { get; set; }
    public string Nome { get; set; }
    public List<string> Cidades { get; set; }
}