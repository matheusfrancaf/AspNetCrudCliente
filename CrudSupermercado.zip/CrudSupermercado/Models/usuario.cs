namespace CrudSupermercado.Models;

public class Usuario : Entity
{
    public string Login { get; set; }
    public string Senha { get; set; }
}